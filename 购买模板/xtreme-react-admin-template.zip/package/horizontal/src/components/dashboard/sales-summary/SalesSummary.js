import React from "react";
import {
  Card,
  CardBody,
  CardTitle,
  CardSubtitle,
  Col,
  Row,
  CustomInput,
} from "reactstrap";
import * as S from "../";
import Chart from "react-apexcharts";

//Line chart
const optionssalesummary = {
  chart: {
    id: "basic-bar",
    type: "area",
    toolbar: {
      show: false,
    },
  },

  dataLabels: {
    enabled: false,
  },
  stroke: {
    curve: "smooth",
    width: 2,
  },
  colors: ["#4fc3f7", "#7460ee"],
  legend: {
    show: false,
  },
  markers: {
    size: 3,
  },
  xaxis: {
    categories: [1, 2, 3, 4, 5, 6, 7, 8, 9],
    labels: {
      show: true,
      style: {
        colors: [
          "#99abb4",
          "#99abb4",
          "#99abb4",
          "#99abb4",
          "#99abb4",
          "#99abb4",
          "#99abb4",
          "#99abb4",
        ],
        fontSize: "12px",
        fontFamily: "'Nunito Sans', sans-serif",
      },
    },
  },
  yaxis: {
    labels: {
      show: true,
      style: {
        colors: [
          "#99abb4",
          "#99abb4",
          "#99abb4",
          "#99abb4",
          "#99abb4",
          "#99abb4",
          "#99abb4",
          "#99abb4",
        ],
        fontSize: "12px",
        fontFamily: "'Nunito Sans', sans-serif",
      },
    },
  },
  grid: {
    borderColor: "rgba(0,0,0,0.1)",
    xaxis: {
      lines: {
        show: true,
      },
    },
    yaxis: {
      lines: {
        show: true,
      },
    },
  },
  tooltip: {
    theme: "dark",
  },
};
const seriessalessummry = [
  {
    name: "Site A view",
    data: [0, 5, 6, 8, 25, 9, 8, 24],
  },
  {
    name: "Site B view",
    data: [0, 3, 1, 2, 8, 1, 5, 1],
  },
];

const SalesSummary = () => {
  return (
    <Card>
      <CardBody>
        <div className="d-md-flex align-items-center">
          <div>
            <CardTitle>Sales Summary</CardTitle>
            <CardSubtitle>Overview of Latest Month</CardSubtitle>
          </div>
          <div className="ml-auto d-flex no-block align-items-center">
            <ul className="list-inline font-12 dl mr-3 mb-0">
              <li className="border-0 p-0 text-info list-inline-item">
                <i className="fa fa-circle"></i> Iphone
              </li>
              <li className="border-0 p-0 text-primary list-inline-item">
                <i className="fa fa-circle"></i> Ipad
              </li>
            </ul>
            <div className="dl">
              <CustomInput type="select" id="exampleCustomSelect">
                <option value="">Monthly</option>
                <option>Daily</option>
                <option>Weekly</option>
                <option>Yearly</option>
              </CustomInput>
            </div>
          </div>
        </div>
        <Row>
          <Col lg="4">
            <h1 className="mb-0 mt-4">$6,890.68</h1>
            <h6 className="font-light text-muted">Current Month Earnings</h6>
            <h3 className="mt-4 mb-0">1,540</h3>
            <h6 className="font-light text-muted">Current Month Sales</h6>
            <a className="btn btn-info my-3 p-3 px-4" href="/">
              Last Month Summary
            </a>
          </Col>
          <Col lg="8">
            <div className="campaign ct-charts">
              <div
                className="chart-wrapper"
                style={{ width: "100%", margin: "0 auto", height: 250 }}
              >
                <Chart
                  options={optionssalesummary}
                  series={seriessalessummry}
                  type="area"
                  height="250"
                />
              </div>
            </div>
          </Col>
        </Row>
      </CardBody>
      <CardBody className="border-top">
        <Row className="mb-0">
          <Col lg="3" md="6">
            <S.Statistics
              textColor="orange"
              icon="wallet"
              title="Wallet Balance"
              subtitle="$3,567.53"
            />
          </Col>
          <Col lg="3" md="6">
            <S.Statistics
              textColor="cyan"
              icon="star-circle"
              title="Referral Earnings"
              subtitle="$769.08"
            />
          </Col>
          <Col lg="3" md="6">
            <S.Statistics
              textColor="info"
              icon="shopping"
              title="Estimate Sales"
              subtitle="5489"
            />
          </Col>
          <Col lg="3" md="6">
            <S.Statistics
              textColor="primary"
              icon="currency-usd"
              title="Earnings"
              subtitle="$23,568.90"
            />
          </Col>
        </Row>
      </CardBody>
    </Card>
  );
};

export default SalesSummary;
