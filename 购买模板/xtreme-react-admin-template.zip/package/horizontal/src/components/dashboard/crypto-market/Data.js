const MarketData = [
    [
        '<i class="display-7 cc XRP" title="XRP"></i>',
        '<div><h6><a class="font-medium link" href="JavaScript: void(0);"> Ripple</a></h6><small class="text-muted">XRP</small></div>',
        "$1.67",
        "$61,191,183,730",
        "$10,133,400,000",
        '<span class="badge badge-success"><i class="fa fa-chevron-up"></i> 66.26%</span>',
        '<span class="badge badge-danger"><i class="fa fa-chevron-down"></i> -16.48%</span>'
    ],

];

export { MarketData };