import React from "react";
import Search from "./Search";

export default () => {
    return (
        <div className="bg-light p-4">
            <Search />
        </div>
    );
}
