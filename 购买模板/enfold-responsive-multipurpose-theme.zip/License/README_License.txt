This WordPress theme is comprised of two parts:


(1) The PHP code is licensed under the GPL license as is WordPress itself.  You will find a copy of the license text in the same directory as this text file. Or you can read it here:

http://codex.wordpress.org/GPL



(2) All other parts of the theme including, but not limited to the CSS code, images, and design are licensed according to the license purchased. Read about licensing details here: 

http://wiki.envato.com/support/legal-terms/licensing-terms/