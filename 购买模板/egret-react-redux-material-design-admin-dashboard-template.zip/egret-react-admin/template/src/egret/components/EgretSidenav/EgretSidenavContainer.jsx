import React from "react";

const EgretSidenavContainer = ({ children }) => {
  return <div className="egret-sidenav-container">{children}</div>;
};

export default EgretSidenavContainer;
