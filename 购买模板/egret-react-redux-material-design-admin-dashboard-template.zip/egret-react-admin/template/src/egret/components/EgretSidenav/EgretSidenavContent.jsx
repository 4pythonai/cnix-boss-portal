import React from "react";

const EgretSidenavContent = ({ children }) => {
  return <div className={`egret-sidenav-content h-100`}>{children}</div>;
};

export default EgretSidenavContent;
