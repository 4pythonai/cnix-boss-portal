/**
 * Styles
 */
import './style.scss';

/**
 * External Dependencies
 */
import Slider from 'rc-slider';

export * from 'rc-slider';

export default Slider;
