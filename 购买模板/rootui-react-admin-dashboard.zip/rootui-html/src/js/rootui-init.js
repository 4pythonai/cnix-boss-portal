import { options } from '../../../common-assets/js/rootui-parts/_options';

if ( typeof window.RootUI !== 'undefined' ) {
    window.RootUI.setOptions( options );
    window.RootUI.init();
}
