import '!!script-loader!../../../common-assets/js/yaybar/yaybar.js';
